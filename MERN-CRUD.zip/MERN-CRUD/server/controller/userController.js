import User from "../model/userModel.js";
import UserModel from "../model/userAuthenticationModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

export const create = async (req, res) => {
  try {
    const userData = new User(req.body);

    if (!userData) {
      return res.status(404).json({ msg: "user data not found" });
    }

    const savedData = await userData.save()
    res.status(200).json(savedData)

  } catch(error) {
    res.status(500).json({error : error})
  }
};

export const getAll = async(req , res) => {

    try {

        const userData = await User.find()
        
        if(!userData) {
            return res.status(404).json({ msg: "user data not found" });
        }

        res.status(200).json(userData)
        
      } catch(error) {
        res.status(500).json({error : error})
      }

}

export const getone = async (req , res) => {
    try {

        const id = req.params.id
        const userExist = await User.findById(id)

        if(!userExist) {
            return res.status(404).json({ msg: "user data not found" });
        }
        res.status(200).json(userExist)

        
    } catch (error) {
        res.status(500).json({error : error})
    }
}

export const update = async(req , res) => {
    try {

        const id = req.params.id
        const userExist = await User.findById(id)

        if(!userExist) {
            return res.status(404).json({ msg: "user data not found" });
        }

        const updatedData = await User.findByIdAndUpdate(id , req.body , {new:true})
        res.status(200).json({msg : "User Updated Successfully"})

    } catch (error) {
        res.status(500).json({error : error})
    }
}

export const deleteUser = async (req , res) => {
    try {

        const id = req.params.id
        const userExist = await User.findById(id)

        if(!userExist) {
            return res.status(404).json({ msg: "user data not found" });
        }

        const deleteData = await User.findByIdAndDelete(id) 
        res.status(200).json({ msg: "data deleted successfully" })

        
    } catch (error) {
        res.status(500).json({error : error})
        
    }
}

export const signup = async (req, res) => {
    const name = req.body.name;
    const email = req.body.email;
    const passwordRaw = req.body.password;
  
    try {
      if (!name || !email || !passwordRaw) {
        res.status(401).json({ message: "Enter Required Fields" });
      }
  
      const existingUsername = await UserModel.findOne({
        name: name,
      }).exec();
  
      if (existingUsername) {
        return res.status(401).json({ message: "Username Already Taken" });
      }
  
      const existingEmail = await UserModel.findOne({ email: email }).exec();
  
      if (existingEmail) {
        return res.status(401).json({ message: "Email Already Existed" });
      }
  
      const passwordHashed = await bcrypt.hash(passwordRaw, 10);
  
      const newUser = await UserModel.create({
        name: name,
        email: email,
        password: passwordHashed,
      });
  
      res.status(201).json(newUser);
    } catch (error) {
      console.log(error);
    }
  };
  
  export const login = async (req, res) => {
    const email = req.body.email;
    const password = req.body.password;
  
    try {
      if (!email || !password) {
        res.status(401).json({ message: "Enter Required Fields" });
      }
  
      const user = await UserModel.findOne({ email });
  
      if (!user) {
        return res
          .status(401)
          .json({ message: "User Does Not Exist SignIn Instead" });
      }
  
      const validPassword = await bcrypt.compare(password, user.password);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid Password" });
      }
  
      const tokenData = {
        id: user._id,
        email: user.email,
      };
  
      const token = jwt.sign(tokenData, "jwt-secret-key", { expiresIn: "1d" });
  
      res.cookie("token", token);
  
      return res.json({ message: "Success" });
    } catch (error) {
      console.log(error);
    }
  };
  
  export const verifyToken = async (req, res, next) => {
    try {
      const cookies = req.cookies?.token;
      console.log(cookies)
  
      if (cookies) {
        jwt.verify(cookies, "jwt-secret-key", (err, user) => {
          if (err) {
            return res.status(400).json({ message: "Invalid Token" });
          }
  
          req.id = user.id;
  
          next();
        });
      }
    } catch (error) {
      console.log(error);
    }
  };
  
  
  export const logout = async (req, res) => {
    try {
      const cookies = req.cookies.token;
      if (cookies) {
        await res.cookie("token", "", {
          httpOnly: true,
          expires: new Date(0),
        });
        return res.json({ message: "User Logged Out Successfully" });
      }
    } catch (error) {
      console.log(error);
    }
  };
  
  