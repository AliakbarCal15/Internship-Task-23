import express from "express";
import mongoose from "mongoose";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import cors from "cors";
import route from "./routes/userRoute.js";

const app = express();
app.use(bodyParser.json());
app.use(cors({
  origin: ["http://localhost:5173"],
  methods: ["GET", "POST" , "PUT" , "DELETE" , "PATCH"],
  credentials: true,
}));
dotenv.config();

const PORT = process.env.PORT;
const URL = process.env.MONGOURL;

mongoose
  .connect(URL)
  .then(
    () => console.log("mongo db connected"),
    app.listen(PORT, () => {
      console.log(`server is running on ${PORT}`);
    })
  )
  .catch((error) => console.log(error));


app.use("/api" , route)
