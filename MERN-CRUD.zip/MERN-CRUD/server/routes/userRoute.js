import express from "express";
import {
  create,
  deleteUser,
  getAll,
  getone,
  update,
  signup,
  login,
  verifyToken,
  logout,
} from "../controller/userController.js";
const route = express.Router();

route.get("/getall", getAll);
route.get("/getone/:id", getone);
route.post("/create", create);
route.put("/update/:id", update);
route.delete("/delete/:id", deleteUser);
route.post("/signup", signup);
route.post("/login", login);
route.post("/logout", verifyToken, logout);

export default route;
