import "./App.css";
import { Route, Routes } from "react-router-dom";
// import { RouterProvider, createBrowserRouter } from "react-router-dom";
import User from "./components/getuser/User";
import Add from "./components/adduser/Add";
import Edit from "./components/updateuser/Edit";
import HomePage from "./components/homePage/HomePage";
import LoginPage from "./components/loginPage/LoginPage";
import SignUpPage from "./components/signupPage/SignupPage";
import Navbar from "./components/navbar/Navbar";
import Protected from "./components/protected/Protected";

function App() {
  // const route = createBrowserRouter([
  //   {
  //     path: "/",
  //     element: <HomePage />,
  //   },
  //   {
  //     path: "/login",
  //     element: <LoginPage />,
  //   },
  //   {
  //     path: "/signup",
  //     element: <SignUpPage />,
  //   },
  //   {
  //     path: "/user",
  //     element: <User />,
  //   },

  //   {
  //     path: "/add",
  //     element: <Add />,
  //   },

  //   {
  //     path: "/edit/:id",
  //     element: <Edit />,
  //   },
  // ]);

  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/user" element={<Protected Component={User}/>}/>
        <Route path="/add" element={<Protected Component={Add}/>}/>
        <Route path="/edit/:id" element={<Protected Component={Edit}/>}/>
        <Route path="/login" element={<LoginPage />}/>
        <Route path="/signup" element={<SignUpPage />}/>
      </Routes>
    </>
  );
}

export default App;
