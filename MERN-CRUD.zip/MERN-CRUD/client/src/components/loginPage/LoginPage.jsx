import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LoginPage.css";
import toast from "react-hot-toast";


const LoginPage = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState();
  const [password, setPassword] = useState();

  axios.defaults.withCredentials = true

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
     await axios.post("http://localhost:8000/api/login", { email, password })
     localStorage.setItem("isloggedIn" , true )
      toast.success("User LoggedIn Successfully", {
        position: "top-right",
      });
      navigate("/user");
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message, {
          position: "top-right",
        });
      }
    }
  };

  

  return (
    <>
      <div className="login_mian_div">
        <div className="login_div">
          <h1>Login</h1>
          <form onSubmit={handleSubmit}>
            <div className="login_email">
              <label htmlFor="email">Email:</label>
              <input
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                id="email"
                name="email"
                placeholder="Enter Email"
              />
            </div>
            <div className="login_password">
              <label htmlFor="password">Password:</label>
              <input
                onChange={(e) => setPassword(e.target.value)}
                type="password"
                id="password"
                name="password"
                placeholder="Enter Password"
              />
            </div>
            <button type="submit" className="login_button">
              Register
            </button>
          </form>
        </div>
      </div>
     
    </>
  );
};

export default LoginPage;
