import { Link } from "react-router-dom";
import "./Navbar.css";
import toast from "react-hot-toast";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();

  const logout = async () => {
    try {
      await axios.post("http://localhost:8000/api/logout").then(() => {
        toast.success("User LoggedOut Successfully", {
          position: "top-right",
        });
      });
      localStorage.removeItem("isloggedIn");
      navigate("/login");
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message, {
          position: "top-right",
        });
      }
    }
  };

  return (
    <>
      <div className="navbvar_main_div">
        <div className="navbar">
          <Link to="/" style={{ textDecoration: "none", color: "black" }}>
            <div className="navbar_div">
              <h1>
                User Management 
              </h1>
            </div>
          </Link>
        </div>
        <div>
          <Link to="/user">
            <button className="navbar_login_button">User List</button>
          </Link>

          <button onClick={logout} className="navbar_upload_button">
            Logout Button
          </button>

          <Link to="/login">
            <button className="navbar_login_button">Login</button>
          </Link>
          <Link to="/signup">
            <button className="navbar_signup_button">SignUp</button>
          </Link>
        </div>
      </div>
    </>
  );
};

export default Navbar;
