import "./HomePage.css";

const HomePage = () => {
  return (
    <>
      <div className="homepage_main_div">
        <div className="homepage_div">
          <h1 className="homepage_dashed">User Management</h1>
        </div>
      </div>
    </>
  );
};

export default HomePage;
