import axios from "axios";
import { useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router-dom";
import "./SignupPage.css"

const SignUpPage = () => {
  const navigate = useNavigate();

  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      await axios
        .post("http://localhost:8000/api/signup", {
          name,
          email,
          password,
        })
        .then(() => {
          toast.success("User Registered Successfully", {
            position: "top-right",
          });
        });

      navigate("/login");
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message, {
          position: "top-right",
        });
      }
    }
  };

  return (
    <>
      <div className="signup_mian_div">
        <div className="signup_div">
          <h1>SignUp</h1>
          <form onSubmit={handleSubmit}>
            <div className="signup_name">
              <label htmlFor="name">Name:</label>
              <input
                onChange={(e) => setName(e.target.value)}
                type="text"
                id="name"
                name="name"
                placeholder="Enter Name"
              />
            </div>
            <div className="signup_email">
              <label htmlFor="email">Email:</label>
              <input
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                id="email"
                name="email"
                placeholder="Enter Email"
              />
            </div>
            <div className="signup_password">
              <label htmlFor="password">Password:</label>
              <input
                onChange={(e) => setPassword(e.target.value)}
                type="password"
                id="password"
                name="password"
                placeholder="Enter Password"
              />
            </div>
            <button type="submit" className="signup_button">
              Register
            </button>
          </form>
        </div>
      </div>
    </>
  );
};

export default SignUpPage;
