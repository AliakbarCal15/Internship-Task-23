import { Link, useParams, useNavigate } from "react-router-dom";
import "../adduser/add.css";
import { useState } from "react";
import { useEffect } from "react";
import axios from "axios";
import toast from "react-hot-toast";

const Edit = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [user, setUser] = useState({ fname: " ", lname: " ", email: " " });

  const inputChangeHandler = (e) => {
    const { name, value } = e.target;

    setUser({ ...user, [name]: value });
  };

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/getone/${id}`)
      .then((res) => {
        setUser(res.data);
      })
      .catch((error) => console.log(error));
  }, [id]);

  const submitForm = async (e) => {
    e.preventDefault();

    await axios
      .put(`http://localhost:8000/api/update/${id}`, user)
      .then(() => {
        toast.success(`User Updated Successfully`, { position: "top-right" });
        navigate("/user");
      })
      .catch((error) => console.log(error));
  };

  return (
    <div className="adduser">
      <Link to={"/"}>Back</Link>
      <h3>Update User</h3>
      <form className="addUserForm" onSubmit={submitForm}>
        <div className="inputGroup">
          <label htmlFor="fname">First Name</label>
          <input
            type="text"
            onChange={inputChangeHandler}
            value={user.fname}
            id="fname"
            name="fname"
            autoComplete="off"
            placeholder="First Name"
          />

          <label htmlFor="lname">Last Name</label>
          <input
            type="text"
            onChange={inputChangeHandler}
            value={user.lname}
            id="lname"
            name="lname"
            autoComplete="off"
            placeholder="Last Name"
          />

          <label htmlFor="email">Email</label>
          <input
            type="email"
            onChange={inputChangeHandler}
            value={user.email}
            id="email"
            name="email"
            autoComplete="off"
            placeholder="Email"
          />

          <div className="inputgroup">
            <button type="submit">Update User</button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Edit;
